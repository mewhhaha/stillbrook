// Grain Tetris — a Deno desktop app.
// Run in a window:  deno desktop main.ts
// Build a binary:   deno desktop --output grain-tetris main.ts
// Or plain browser: deno run --allow-read --allow-net main.ts

const dir = import.meta.dirname!;
const html = await Deno.readFile(`${dir}/index.html`);
const wasm = await Deno.readFile(`${dir}/tetris.wasm`);

Deno.serve((req) => {
  const { pathname } = new URL(req.url);
  if (pathname === "/tetris.wasm") {
    return new Response(wasm, {
      headers: { "content-type": "application/wasm" },
    });
  }
  return new Response(html, {
    headers: { "content-type": "text/html; charset=utf-8" },
  });
});
