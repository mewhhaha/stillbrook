# Grain Tetris

Tetris with the game logic written in [Grain](https://grain-lang.org),
compiled to WebAssembly, rendered on a canvas, and wrapped in a native
window by `deno desktop`.

## Run it

Needs [Deno](https://deno.com) 2.9 or newer.

    deno desktop main.ts

That opens the game in a native window. To build a distributable app
bundle for your platform instead:

    deno desktop --include ./index.html --include ./tetris.wasm --output GrainTetris main.ts

No desktop needed? It is also just a web page:

    deno run --allow-read --allow-net main.ts    # then open http://localhost:8000

## Rebuild the wasm

Install the [Grain compiler](https://grain-lang.org/docs/getting_grain), then:

    grain compile tetris.gr --release -o tetris.wasm

The game logic lives entirely in `tetris.gr`; `index.html` only draws
the board and forwards key presses across the WebAssembly boundary.

## Keys

left/right move · up rotates · down soft drop · space hard drop ·
P pauses · R restarts
